<?php defined('BASEPATH') or exit('No direct script access allowed');
/*
| -------------------------------------------------------------------
|  Facebook API Configuration
| -------------------------------------------------------------------
|
| To get Facebook app details you have to create a Facebook app
| at Facebook developers panel (https://developers.facebook.com)
|
*/
$config['facebook_app_id']              = '654238500068170';
$config['facebook_app_secret']          = 'be9dcfaae059c7f0d19cd4d0bad83210';
$config['facebook_login_redirect_url']  = 'users/login/';
$config['facebook_login_type']          = 'web';
$config['facebook_permissions']         = array('email');
$config['facebook_graph_version']       = 'v2.6';
$config['facebook_auth_on_load']        = TRUE;

/*
| -------------------------------------------------------------------
|  Google API Configuration
| -------------------------------------------------------------------
|
| To get Google app details you have to create a Google app
| at Google developers console (https://console.developers.google.com)
|
*/
$config['google_client_id']     = '738975831820-ct8qqtvfhjnsai861rh22b207puehq7r.apps.googleusercontent.com';
$config['google_client_secret'] = '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';
$config['google_redirect_url']  = 'users/login/';

/*
| -------------------------------------------------------------------
|  Twitter API Configuration
| -------------------------------------------------------------------
|
| To get Twitter app details you have to create a Twitter app
| at Twitter Application Management panel (https://apps.twitter.com)
|
*/
$config['twitter_api_key']      = 'RWtfSWJZOVRfaDZMUnlaNDBwQms6MTpjaQ';
$config['twitter_api_secret']   = 'u5yGlpddiLQw5r-vF247b40D8U1DV_zdYdLdT7E30ZP79s0o4F';
$config['twitter_redirect_url'] = 'users/login/';
