<!DOCTYPE html>
<html lang="en">

<head>
	<!-- HEAD-->
	<?php echo $head; ?>
</head>

<body>
	<!-- MAIN CONTENT -->
	<?php echo $maincontent; ?>
	<!-- FOOTER -->
	<?php echo $footer; ?>
</body>

</html>