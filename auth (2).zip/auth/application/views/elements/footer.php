<div class="flex justify-center w-full fixed bottom-0">
	<div class="bg-white px-2 rounded-t">
		<p class="text-center">
			&copy; <?php echo date("Y"); ?> <?php echo $this->config->item('site_name'); ?>. Created by <a class="underline hover:opacity-50" href="https://www.salimi.my" target="_blank">Salimi</a>
		</p>
	</div>
</div>